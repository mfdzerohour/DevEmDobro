import Button from "./components/button/button"

function App() {

  return (
    <>
      <Button />
      <Button />
      <Button />
    </>
  )
}

export default App
