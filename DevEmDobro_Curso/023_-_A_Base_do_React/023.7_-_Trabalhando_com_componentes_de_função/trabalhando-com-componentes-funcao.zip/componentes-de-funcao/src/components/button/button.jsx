import './button.css'

const Button = () => {
  return <button className="btn">Clique aqui</button>
}


export default Button