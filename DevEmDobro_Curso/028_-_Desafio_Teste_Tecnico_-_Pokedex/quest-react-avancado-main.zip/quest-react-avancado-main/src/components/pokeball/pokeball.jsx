const Pokeball = (props) => {

    return (
        <div>
            {props.children}
        </div>
    )
}



export { Pokeball }