import { PokemonDetails } from "../components/pokemon";
const Pokemon = () => {
     return(
         <PokemonDetails />
     )
 }
 export { Pokemon }