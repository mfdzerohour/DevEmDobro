import { PokeList } from "../components/pokemons";

const Pokemons =()=>{
    return(
        <PokeList />
    )
}
export {Pokemons}