import Card from "./components/card/card"
//import Button from "./components/button/button"

function App() {

  return (
      <>
          <Card title="Título Card 1" />
          <Card title="Título Card 2" />
          <Card title="Título Card 3" />
      </>
  );
}

export default App
